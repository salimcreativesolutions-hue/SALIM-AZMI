// Videos load only when they come near the screen, play while visible, pause when not.
// Phones and tablets get the lighter 1440px version.
(function () {
  var small = window.matchMedia('(max-width: 900px)').matches;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var videos = document.querySelectorAll('.lazy-video');

  function load(v) {
    if (v.dataset.loaded) return;
    v.src = small && v.dataset.srcSmall ? v.dataset.srcSmall : v.dataset.src;
    v.dataset.loaded = '1';
  }

  if (!('IntersectionObserver' in window)) {
    videos.forEach(function (v) { load(v); if (!reduce) v.play().catch(function () {}); });
    return;
  }

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      var v = e.target;
      if (e.isIntersecting) {
        load(v);
        if (!reduce) v.play().catch(function () {});
      } else if (!v.paused) {
        v.pause();
      }
    });
  }, { rootMargin: '300px 0px' });

  videos.forEach(function (v) { io.observe(v); });
})();

// Custom cursor (same as the rest of the site): black dot + trailing grey disc.
(function () {
  var S = {}, dot = document.querySelector('.dot.pt'), ring = document.querySelector('.dot.ring');
  if (!dot || !ring) return;
  S.dotEl = dot; S.ringEl = ring;
  if (!window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  S.mx = -100; S.my = -100; S.x = -100; S.y = -100; S.rx = -100; S.ry = -100; S.s = 0.4375; S.rs = 1; S.big = false;
  S.onMove = (e) => {
  if (S.mx < -50) { S.x = S.rx = e.clientX; S.y = S.ry = e.clientY; }
  S.mx = e.clientX; S.my = e.clientY;
  if (!!document.body.classList.contains("cur-on")) (document.body.classList.add('cur-on'),dot.style.opacity=ring.style.opacity=1);
  };
  S.onOver = (e) => {
  const t = e.target;
  S.big = !!(t && t.closest && t.closest('a, button, .opt, [role="button"]'));
  };
  S.onLeave = () => { (document.body.classList.remove('cur-on'),dot.style.opacity=ring.style.opacity=0); };
  document.addEventListener('mousemove', S.onMove);
  document.addEventListener('mouseover', S.onOver);
  document.documentElement.addEventListener('mouseleave', S.onLeave);
  const step = () => {
  S.x += (S.mx - S.x) * 0.38;
  S.y += (S.my - S.y) * 0.38;
  S.rx += (S.mx - S.rx) * 0.1;
  S.ry += (S.my - S.ry) * 0.1;
  S.s += ((S.big ? 1 : 0.4375) - S.s) * 0.2;
  S.rs += ((S.big ? 0 : 1) - S.rs) * 0.2;
  if (S.dotEl) S.dotEl.style.transform = 'translate3d(' + S.x.toFixed(2) + 'px,' + S.y.toFixed(2) + 'px,0) scale(' + S.s.toFixed(3) + ')';
  if (S.ringEl) S.ringEl.style.transform = 'translate3d(' + S.rx.toFixed(2) + 'px,' + S.ry.toFixed(2) + 'px,0) scale(' + Math.max(S.rs, 0.001).toFixed(3) + ')';
  S.loop = requestAnimationFrame(step);
  };
  S.loop = requestAnimationFrame(step);
})();

// Hide the header when the footer is on screen (same behaviour as the homepage).
(function () {
  var hdr = document.querySelector('.hdr'), foot = document.querySelector('footer');
  if (!hdr || !foot || !('IntersectionObserver' in window)) return;
  new IntersectionObserver(function (e) { hdr.classList.toggle('hide', e[0].isIntersecting); }, { threshold: 0.15 }).observe(foot);
})();
