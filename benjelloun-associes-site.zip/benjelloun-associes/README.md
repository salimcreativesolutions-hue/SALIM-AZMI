# Benjelloun & Associés — case study

Drop this whole `benjelloun-associes` folder into the root of your website project in Visual Studio Code.

```
your-site/
├── index.html            ← your homepage
├── projets.html
├── contact.html
└── benjelloun-associes/  ← this folder
    ├── index.html        ← the case study page
    ├── style.css
    ├── script.js
    ├── project-card.html ← card to paste into your homepage grid
    └── assets/
        ├── img/          ← WebP images (2880px + 1440px) and video posters
        └── video/        ← MP4 videos (2880px + 1440px) and the pencil card video
```

## Steps
1. Copy the folder into your site root.
2. Open `benjelloun-associes/project-card.html`, copy the card and paste it into the project grid on your homepage and on your Projets page.
3. Check the links in the header, the testimonial section and the footer of `index.html` (`../index.html`, `../projets.html`, `../contact.html`) and rename them if your pages have other names.
4. Preview with the **Live Server** extension in VS Code (right-click `index.html` → Open with Live Server).

## Notes
- Images and videos load lazily. Phones get the 1440px versions automatically.
- Videos are muted, loop, and only play while visible on screen.
- The page uses the same header, footer, cursor and fonts (Inter Tight + Geist Mono) as the rest of your site. The slide images keep the TT Firs Neue / TT Hoves Pro trial fonts, fine for local use.
- The client testimonial is a placeholder: replace the quote with the real one from the firm.
